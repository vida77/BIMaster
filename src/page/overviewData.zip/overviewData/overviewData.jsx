import React from 'react'
import { hashHistory } from 'react-router';
import {Tabs, Card, Radio, Icon,Table, Row, Col, Button, Pagination} from 'antd';
import moment from 'moment';
import CitySelect from '../../components/searchBox/citySelect'
import ExportFileCom from '../../components/exportFile/exportFile'
import FunnelChart from '../../components/chart/overviewData'
import LineBarChart from '../../components/chart/overviewData/lineBarChart'
import CumulateBarChart from '../../components/chart/overviewData/cumulateBarChart'
import DateBox from '../../components/searchBox/dateBox'

import {getFun} from '../../utils/api'
import {objectToArr, dateDiff, milliFormat} from '../../utils/dataHandle'

import './overviewData.less'

const TabPane = Tabs.TabPane;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;

export  default class overviewData extends React.Component {
    constructor(props){
        super(props)
        this.state = {
            dateType: 0,
            dateTypes: {
                0: "日",
                1: "周",
            },
            dateTypeNum: {
                0: 0,
                1: 1,
            },
            // 漏斗图
            funnelchartData: 
            [
                {value: 60, name: '日均完成订单司机'},
                {value: 40, name: '日均中标司机'},
                {value: 20, name: '日均抢单司机'},
                {value: 80, name: '日均派单司机'},
                {value: 100, name: '日均有效在线司机'},
                {value: 140, name: '日均在线司机'}
            ],
            // 横向堆积图
            cumulateBarData:[
                {"create_order":500},
                {"zdqx":120,"ycjd":120,"ycwrj":120,"wckj":100,},
                {"zdqx":120,"zdxz":110,"csxz":80,},
                {"zdqx":90,"drwc":100,"ddfw":70,},
            ],
            // 柱图／折线图
            chartInform: [
                {name: '创建订单量', type: 'bar', filedName: 'a'},
                {name: '有车接单量', type: 'bar', filedName: 'b'},
                {name: '完成订单量', type: 'bar', filedName: 'c'},
                {name: '订单完成率', type: 'line', filedName: 'd'}
            ],
            chartData: {
                '09-03': {
                    'a': 100,
                    'b': 264,
                    'c': 39,
                    'd': 58,
                    'e': 180
                },
                '09-04': {
                    'a': 233,
                    'b': 142,
                    'c': 90,
                    'd': 350,
                    'e': 281
                },
                '09-05': {
                    'a': 190,
                    'b': 174,
                    'c': 68,
                    'd': 58,
                    'e': 180
                },
                '09-06': {
                    'a': 133,
                    'b': 132,
                    'c': 30,
                    'd': 350,
                    'e': 281
                },
                '09-07': {
                    'a': 100,
                    'b': 264,
                    'c': 39,
                    'd': 58,
                    'e': 180
                },
                '09-08': {
                    'a': 233,
                    'b': 142,
                    'c': 90,
                    'd': 350,
                    'e': 281
                },
                '09-09': {
                    'a': 190,
                    'b': 174,
                    'c': 68,
                    'd': 58,
                    'e': 180
                },
                '09-10': {
                    'a': 133,
                    'b': 132,
                    'c': 30,
                    'd': 350,
                    'e': 281
                }
            },
            xData:[],
            // 表格
            tableDataOrder: [],
            tableHeaderOrder: [
                {
                    title: '日期', dataIndex: 'start_time', key: 'start_time',  width: '100px'
                },
                {
                    title: '创建订单量', dataIndex: 'create_order_number', key: 'create_order_number'
                },
                {
                    title: '完成订单量', dataIndex: 'complete_order_number', key: 'complete_order_number'
                },
                {
                    title: '订单完成率', dataIndex: 'complete_order_radio', key: 'complete_order_radio'
                },
            ],
            // 组合表格
            tableHeaderL: [
                {
                    title: '指标', dataIndex: 'name', key: 'name',  width: '138px'
                },
                {
                    title: '数量', dataIndex: 'value', key: 'value', width: '100px'
                }
            ],
            tableHeaderR: [
                {
                    title: '指标', dataIndex: 'name', key: 'name',  width: '138px'
                },
                {
                    title: '数量', dataIndex: 'value', key: 'value', width: '100px'
                }
            ],
            load: false,
        }
    }
    componentWillMount() {
        
    }
    componentDidMount(){
        
    }
    // 点击查询
    searchBtn() {
      
    }
    // 获取下拉框组件参数
    thisSearchParams(params){
        this.setState({
            city: params.city,
        })
    }
    getCityParams(){
        let path = document.location.toString();
        let pathUrl = path.split('#');
        let url = pathUrl[1].split('/');
        let str = url[url.length - 1];
        let city = "";
        let auth = JSON.parse(localStorage.getItem("auth"));
        if(auth){
            let cityObj = auth;
            Object.keys(cityObj).map(item => {
                if(item.indexOf(str) > 0 ){
                    let cityArr = cityObj[item].city;
                    if(cityArr[0] == 'all'){
                        city = '';
                    }else {
                        city = cityArr.join(",")
                    }
                    // city = cityArr[cityArr.length - 1]
                }
            })
        }
        return city;
    }
    // 周，月
    dateTypeChange(e){
    let index = e.target.value;
    this.setState({
        dateType: this.state.dateTypeNum[index]
    })
    let params = {
        dateType: this.state.dateTypeNum[index],
    }
    // 
}
    render(){
        const {dateTypes, load, xData, tableHeaderOrder, tableHeaderL, tableHeaderR,} = this.state;
        const radioChildren = Object.keys(dateTypes).map(item => {
            return <RadioButton key={item} value={item}>{dateTypes[item]}</RadioButton>
        })
        let tableDataL = [{
            key: 'aa',
            name: '创建订单',
            value: 12345,
          },{
            key: 'bb',
            name: '主动取消（派单阶段）',
            value: 2345,
          },{
            key: 'cc',
            name: '有车接单',
            value: 345,
          },{
            key: 'dd',
            name: '有车无人接',
            value: 45,
          },{
            key: 'ee',
            name: '无车可接',
            value: 123,
          },{
            key: 'ff',
            name: '主动取消（决策阶段）',
            value: 234,
          },{
            key: 'gg',
            name: '主动选择',
            value: 34,
          },{
            key: 'hh',
            name: '超时取消',
            value: 23,
          }]
        let tableDataR = [{
            key: 'aa',
            name: '主动取消（服务阶段）',
            value: 12,
          },{
            key: 'bb',
            name: '当日完成',
            value: 115,
          },{
            key: 'cc',
            name: '等待服务',
            value: 55,
          }]
        // let tableDataOrder = [{
        //     key: 'aa',
        //     create_order_number: 1111,
        //     complete_order_number: 222,
        //     complete_order_radio: 33
        //     },{
        //     create_order_number: 1111,
        //     complete_order_number: 222,
        //     complete_order_radio: 33
        //     },{
        //     create_order_number: 1111,
        //     complete_order_number: 222,
        //     complete_order_radio: 33
        // }]
          return (
            <div className="overview-wrapper">
                <div className="">
                    <Card bordered={false}>
                        <div className="search-content">
                            <div className="search-wrapper">
                                <div>
                                    <CitySelect searchParams={params => this.thisSearchParams(params)}></CitySelect>
                                </div>
                            </div>
                            <div className="search-btn-wrapper">
                                <Button type="primary"  icon='search' onClick={this.searchBtn.bind(this)}>查询</Button>
                            </div>
                        </div>
                    </Card>
                    <div className="contentWrap">
                        <div className="chartExcelWrap">
                            <div className="chartExcel chartExcelL">
                                <RadioGroup onChange={this.dateTypeChange.bind(this)}  defaultValue={this.state.dateType} >
                                    {radioChildren}
                                </RadioGroup>
                                <Icon type="arrows-alt" theme="outlined" />
                                <Tabs defaultActiveKey="1">
                                    <TabPane tab="图" key="1">
                                        <LineBarChart  xData={xData} chartInform={this.state.chartInform} chartData={this.state.chartData}></LineBarChart>
                                    </TabPane>
                                    <TabPane tab="表" key="2">
                                        222
                                    </TabPane>
                                </Tabs>
                            </div>
                            <div className="chartExcel chartExcelR">
                                <RadioGroup onChange={this.dateTypeChange.bind(this)}  defaultValue={this.state.dateType} >
                                    {radioChildren}
                                </RadioGroup>
                                <Icon type="arrows-alt" theme="outlined" />
                                <Tabs defaultActiveKey="1" >
                                    <TabPane tab="图" key="1">
                                        <LineBarChart  xData={this.state.xData} chartInform={this.state.chartInform} chartData={this.state.chartData}></LineBarChart>
                                    </TabPane>
                                    <TabPane tab="表" key="2">
                                        222
                                    </TabPane>
                                </Tabs>
                            </div>
                        </div>
                        <div className="chartExcelWrap">
                            <div className="chartExcel chartExcelL">
                                <RadioGroup onChange={this.dateTypeChange.bind(this)}  defaultValue={this.state.dateType} >
                                    {radioChildren}
                                </RadioGroup>
                                <Icon type="arrows-alt" theme="outlined" />
                                <Tabs defaultActiveKey="1" >
                                    <TabPane tab="图" key="1">
                                        <LineBarChart  chartInform={this.state.chartInform} chartData={this.state.chartData}></LineBarChart>
                                    </TabPane>
                                    <TabPane tab="表" key="2">
                                        222
                                    </TabPane>
                                </Tabs>
                            </div>
                            <div className="chartExcel chartExcelR">
                                <RadioGroup onChange={this.dateTypeChange.bind(this)}  defaultValue={this.state.dateType} >
                                    {radioChildren}
                                </RadioGroup>
                                <Icon type="arrows-alt" theme="outlined" />
                                <Tabs defaultActiveKey="1" >
                                    <TabPane tab="图" key="1">
                                        <LineBarChart  chartInform={this.state.chartInform} chartData={this.state.chartData}></LineBarChart>
                                    </TabPane>
                                    <TabPane tab="表" key="2">
                                        222
                                    </TabPane>
                                </Tabs>
                            </div>
                        </div>
                        <div className="chartExcelWrap">
                            <div className="chartExcel chartExcelL">
                                <DateBox searchParams={params => this.thisSearchParams(params)}/>
                                <Icon type="arrows-alt" theme="outlined" />
                                <Tabs defaultActiveKey="1" >
                                    <TabPane tab="图" key="1">
                                    <CumulateBarChart chartData={this.state.cumulateBarData}></CumulateBarChart>
                                    </TabPane>
                                    <TabPane tab="表" key="2">
                                        <Table dataSource={tableDataL} bordered loading={load} columns={tableHeaderL} pagination={false} style={{float:'left'}}></Table>
                                        <Table dataSource={tableDataR} bordered loading={load} columns={tableHeaderR} pagination={false} style={{float:'left'}}></Table>
                                    </TabPane>
                                </Tabs>
                            </div>
                            <div className="chartExcel chartExcelR">
                                <DateBox searchParams={params => this.thisSearchParams(params)}/>
                                <DateBox />
                                <Icon type="arrows-alt" theme="outlined" />
                                <Tabs defaultActiveKey="1" >
                                    <TabPane tab="图" key="1">
                                    <FunnelChart chartData={this.state.funnelchartData}></FunnelChart>
                                    </TabPane>
                                    <TabPane tab="表" key="2">
                                        222
                                    </TabPane>
                                </Tabs>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}